const SHOP_DATA = [
    { id: 'bandage', name: 'Pārsējs', price: 10, icon: 'scrinshots/50px-Bandage.png', charges: 1 },
    { id: 'tourniquet', name: 'Žņaugs', price: 15, icon: 'scrinshots/3460512672_preview_Tourniquet.png', charges: 1 },
    { id: 'saline', name: 'Fizioloģiskais šķīdums', price: 25, icon: 'scrinshots/28px-Saline.png', charges: 1 },
    { id: 'antibiotics', name: 'Antibiotikas', price: 30, icon: 'scrinshots/44px-Broad-spectrum_Antibiotics_icon.png', charges: 1 },
    { id: 'plaster', name: 'Medicīniskais ģipsis', price: 35, icon: 'scrinshots/3460512672_preview_Osteosynthesis Implants.png', charges: 1 },
    { id: 'suture_kit', name: 'Ķirurģiskā adata un diegi', price: 50, icon: 'scrinshots/3460512672_preview_Needle.png', charges: 5 },
    { id: 'forceps', name: 'Ķirurģiskā pincete', price: 60, icon: 'scrinshots/3460512672_preview_Tweezers.png', charges: Infinity },
    { id: 'blood_pack', name: 'Asins maiss', price: 70, icon: 'scrinshots/3460512672_preview_Blood Packs.png', charges: 1 },
    { id: 'scalpel', name: 'Skalpelis', price: 80, icon: 'scrinshots/3460512672_preview_Multipurpose Scalpel.png', charges: Infinity },
    { id: 'morphine', name: 'Morfijs', price: 100, icon: 'scrinshots/50px-Morphine.png', charges: 1 },
    { id: 'defib', name: 'Defibrilators', price: 110, icon: 'scrinshots/3460512672_preview_Manual Defibrillator.png', charges: Infinity },
    { id: 'hp_stim', name: 'Dzīvības stimulators', price: 150, icon: 'scrinshots/50px-Endocrine_Booster.png', charges: 1 }
];

const TRAUMA_POOL = {
    common: [
        { name: 'Skrāpējums', dps: 1, definition: 'Virsmas ādas bojājums.', icd: 'S00.0', icn: 'scrinshots/3460512672_preview_Wounds2.png' },
        { name: 'Sasitums', dps: 2, definition: 'Mīksto audu bojājums bez struktūras maiņas.', icd: 'S00.1', icn: 'scrinshots/3460512672_preview_Wounds1.png' },
        { name: 'Viegla asiņošana', dps: 3, definition: 'Sīko asinsvadu integritātes pārkāpums.', icd: 'S01.0', icn: 'scrinshots/3460512672_preview_Bleeding.png' }
    ],
    rare: [
        { name: 'Dziļš griezums', dps: 7, definition: 'Brūce, kas skar zemādas audus.', icd: 'S01.1', icn: 'scrinshots/3460512672_preview_Wounds3.png' },
        { name: 'Kaula lūzums', dps: 5, definition: 'Pilnīgs vai daļējs kaula integritātes pārkāpums.', icd: 'S02.0', icn: 'scrinshots/3460512672_preview_Fractures (2).png' },
        { name: 'Asins saindēšanās', dps: 10, definition: 'Sistēmiska iekaisuma reakcija uz infekciju.', icd: 'A41.9', icn: 'scrinshots/3460512672_preview_Inflammation.png' }
    ],
    lethal: [
        { name: 'Arteriālā asiņošana', dps: 35, definition: 'Kritisks asins zudums no artērijas.', icd: 'S01.2', icn: 'scrinshots/3460512672_preview_Aortic Rupture.png' },
        { name: 'Iekšējā asiņošana', dps: 30, definition: 'Asins noplūde ķermeņa dobumos vai audos.', icd: 'S06.0', icn: 'scrinshots/3460512672_preview_Internal Bleeding.png' },
        { name: 'Sirdsdarbības apstāšanās', dps: 40, definition: 'Efektīvas sirdsdarbības pārtraukšana.', icd: 'I46.9', icn: 'scrinshots/3460512672_preview_Heart Attack.png' },
        { name: 'Galvaskausa lūzums', dps: 25, definition: 'Galvaskausa kaulu bojājums.', icd: 'S02.9', icn: 'scrinshots/3460512672_preview_Fractures1.png' }
    ]
};

let state = {
    credits: 0,
    hp: 200,
    maxHp: 200,
    inventory: [],
    activeInjuries: [],
    selectedItemIdx: -1,
    isGameOver: false,
    tickTimer: 5000,
    survivalSeconds: 0 // Переменная для подсчета времени жизни
};

window.onload = () => {
    initShop();
    renderInventory();
    renderWiki();
    startGameLoop();
    setupEventListeners();
    updateUI();
};

function setupEventListeners() {
    document.querySelectorAll('.body-part').forEach(part => {
        part.addEventListener('click', () => handlePartClick(part.dataset.part));
    });
    const modal = document.getElementById('manual-modal');
    document.getElementById('manual-btn').onclick = () => modal.classList.remove('hidden');
    document.querySelector('.close-modal').onclick = () => modal.classList.add('hidden');
    document.getElementById('restart-btn').onclick = resetGame;
}

function handlePartClick(partId) {
    if (state.isGameOver) return;
    if (state.selectedItemIdx !== -1) {
        attemptTreatment(partId);
        return;
    }
    const income = { head: 3, torso: 2, 'arm-l': 1, 'arm-r': 1, 'leg-l': 1, 'leg-r': 1 };
    state.credits += income[partId] || 1;
    updateUI();
    if (Math.random() < 0.08) {
        inflictInjury(partId);
    }
}

function inflictInjury(partId) {
    const roll = Math.random();
    let rarity = 'common';
    if (roll < 0.05) rarity = 'lethal';
    else if (roll < 0.25) rarity = 'rare';
    
    const pool = TRAUMA_POOL[rarity];
    let potential = pool;
    if (partId !== 'torso') {
        potential = pool.filter(t => t.name !== 'Sirdsdarbības apstāšanās' && t.name !== 'Iekšējā asiņošana');
    }
    if (partId !== 'head') {
        potential = potential.filter(t => t.name !== 'Galvaskausa lūzums');
    }
    
    const injuryTemplate = potential.length > 0 ? potential[Math.floor(Math.random() * potential.length)] : TRAUMA_POOL.common[0];
    
    const newInjury = {
        id: Date.now() + Math.random(),
        part: partId,
        name: injuryTemplate.name,
        dps: injuryTemplate.dps,
        stage: 0,
        rarity: rarity
    };
    
    state.activeInjuries.push(newInjury);
    updateBodyPartVisuals();
    updateUI();
}

function attemptTreatment(partId) {
    const item = state.inventory[state.selectedItemIdx];
    if (!item) return;

    if (item.id === 'hp_stim') {
        state.maxHp += 20;
        state.hp = state.maxHp;
        showActionHint("STIMULATORS IEVADĪTS: MAX HP PALĪELINĀTS");
        consumeItem();
        updateUI();
        updateBodyPartVisuals();
        return;
    }
    if (item.id === 'blood_pack') {
        state.hp = Math.min(state.maxHp, state.hp + 30);
        showActionHint("ASINS MAISS IZMANTOTS: +30 HP");
        consumeItem();
        updateUI();
        updateBodyPartVisuals();
        return;
    }
    if (item.id === 'saline') {
        state.hp = Math.min(state.maxHp, state.hp + 15);
        showActionHint("FIZIOLOĢISKAIS ŠĶĪDUMS IEVADĪTS: +15 HP");
        consumeItem();
        updateUI();
        updateBodyPartVisuals();
        return;
    }
    if (item.id === 'morphine') {
        state.hp = Math.min(state.maxHp, state.hp + 10);
        showActionHint("MORFIJS IEVADĪTS: +10 HP");
        consumeItem();
        updateUI();
        updateBodyPartVisuals();
        return;
    }

    const partInjuries = state.activeInjuries.filter(i => i.part === partId);
    if (partInjuries.length === 0) {
        failureTreatment();
        return;
    }

    let success = false;
    let fullyHealed = false;
    let targetInjury = null;

    for (let injury of partInjuries) {
        if ((injury.rarity === 'common' || injury.name === 'Dziļš griezums') && item.id === 'bandage') {
            success = true; fullyHealed = true; targetInjury = injury; break;
        }
        if (injury.name === 'Asins saindēšanās' && item.id === 'antibiotics') {
            success = true; fullyHealed = true; targetInjury = injury; break;
        }
        if (injury.name === 'Kaula lūzums') {
            if (injury.stage === 0 && item.id === 'forceps') { injury.stage = 1; success = true; targetInjury = injury; break; }
            if (injury.stage === 1 && item.id === 'plaster') { success = true; fullyHealed = true; targetInjury = injury; break; }
        }
        if (injury.name === 'Arteriālā asiņošana') {
            if (injury.stage === 0 && item.id === 'tourniquet') { injury.stage = 1; injury.dps = 2; success = true; targetInjury = injury; break; }
            if (injury.stage === 1 && item.id === 'suture_kit') { injury.stage = 2; success = true; targetInjury = injury; break; }
            if (injury.stage === 2 && item.id === 'tourniquet') { success = true; fullyHealed = true; targetInjury = injury; break; }
        }
        if (injury.name === 'Iekšējā asiņošana' || injury.name === 'Galvaskausa lūzums') {
            if (injury.stage === 0 && item.id === 'scalpel') { injury.stage = 1; success = true; targetInjury = injury; break; }
            if (injury.stage === 1 && item.id === 'forceps') { injury.stage = 2; success = true; targetInjury = injury; break; }
            if (injury.stage === 2 && item.id === 'suture_kit') { success = true; fullyHealed = true; targetInjury = injury; break; }
        }
        if (injury.name === 'Sirdsdarbības apstāšanās') {
            if (injury.stage === 0 && item.id === 'scalpel') { injury.stage = 1; success = true; targetInjury = injury; break; }
            if (injury.stage === 1 && item.id === 'forceps') { injury.stage = 2; success = true; targetInjury = injury; break; }
            if (injury.stage === 2 && item.id === 'defib') { injury.stage = 3; success = true; targetInjury = injury; break; }
            if (injury.stage === 3 && item.id === 'suture_kit') { success = true; fullyHealed = true; targetInjury = injury; break; }
        }
    }

    if (success && targetInjury) {
        if (fullyHealed) {
            const idx = state.activeInjuries.findIndex(i => i.id === targetInjury.id);
            if (idx !== -1) state.activeInjuries.splice(idx, 1);
            showActionHint("TRAUMA NOVĒRSTA!");
        } else {
            showActionHint("ETAPS PABEIGTS, TURPINIET PROCEDŪRU");
        }
        consumeItem();
    } else {
        failureTreatment();
    }

    if (state.hp <= 0) gameOver();
    updateUI();
    updateBodyPartVisuals();
}

function initShop() {
    const shopContainer = document.getElementById('shop-items');
    shopContainer.innerHTML = "";
    SHOP_DATA.forEach(item => {
        const div = document.createElement('div');
        div.className = 'shop-item';
        div.innerHTML = `<span class="item-name">${item.name}</span> <span class="item-price">${item.price}c</span>`;
        div.onclick = () => buyItem(item);
        shopContainer.appendChild(div);
    });
}

function buyItem(itemData) {
    if (state.credits >= itemData.price) {
        state.credits -= itemData.price;
        const invItem = state.inventory.find(i => i.id === itemData.id && i.charges !== Infinity);
        if (invItem) {
            invItem.count = (invItem.count || 1) + 1;
        } else {
            state.inventory.push({ ...itemData, count: 1 });
        }
        renderInventory();
        updateUI();
    } else {
        showActionHint("NEPIETIEK KREDĪTU!");
    }
}

function renderInventory() {
    const grid = document.getElementById('inventory-grid');
    grid.innerHTML = '';
    for (let i = 0; i < 12; i++) {
        const slot = document.createElement('div');
        slot.className = 'inv-slot';
        if (state.selectedItemIdx === i) slot.classList.add('selected');
        const item = state.inventory[i];
        if (item) {
            slot.innerHTML = `
                <img src="${item.icon}" alt="${item.name}">
                <span>${item.name}</span>
                <span class="slot-count">${item.charges === Infinity ? '∞' : (item.count > 1 ? 'x'+item.count : item.charges)}</span>
            `;
            slot.onclick = () => selectItem(i);
        }
        grid.appendChild(slot);
    }
}

function selectItem(idx) {
    if (state.selectedItemIdx === idx) state.selectedItemIdx = -1;
    else state.selectedItemIdx = idx;
    renderInventory();
}

function consumeItem() {
    const item = state.inventory[state.selectedItemIdx];
    if (!item) return;
    if (item.charges === Infinity) {
        state.selectedItemIdx = -1;
    } else {
        if (item.id === 'suture_kit') {
            item.charges--;
            if (item.charges <= 0) {
                if (item.count > 1) { item.count--; item.charges = 5; }
                else { state.inventory.splice(state.selectedItemIdx, 1); state.selectedItemIdx = -1; }
            }
        } else {
            if (item.count > 1) item.count--;
            else { state.inventory.splice(state.selectedItemIdx, 1); state.selectedItemIdx = -1; }
        }
    }
    renderInventory();
}

function startGameLoop() {
    setInterval(() => {
        if (state.isGameOver) return;
        let totalDps = 0;
        state.activeInjuries.forEach(inj => totalDps += inj.dps);
        state.hp -= totalDps;
        if (state.hp <= 0) { state.hp = 0; gameOver(); }
        updateUI();
    }, 5000);
    
    setInterval(() => {
        if (state.isGameOver) return;
        state.tickTimer -= 100;
        if (state.tickTimer <= 0 || isNaN(state.tickTimer)) state.tickTimer = 5000;
        document.getElementById('tick-timer').innerText = `NĀKAMAIS TICKS: ${(state.tickTimer / 1000).toFixed(1)}s`;
    }, 100);

    // Добавлен цикл подсчета времени выживания (срабатывает каждую 1 секунду)
    setInterval(() => {
        if (state.isGameOver) return;
        state.survivalSeconds++;
        updateSurvivalTimerUI();
    }, 1000);
}

// Новая функция форматирования и обновления визуального таймера
function updateSurvivalTimerUI() {
    const minutes = Math.floor(state.survivalSeconds / 60);
    const seconds = state.survivalSeconds % 60;
    const formattedTime = minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;
    document.getElementById('survival-timer').innerText = `IZDZĪVOŠANAS LAIKS: ${formattedTime}`;
}

function updateUI() {
    document.getElementById('credits-count').innerText = Math.floor(state.credits);
    document.getElementById('hp-text').innerText = `${Math.ceil(state.hp)} / ${state.maxHp}`;

    const percent = Math.max(0, (state.hp / state.maxHp) * 100);
    document.getElementById('hp-bar-inner').style.width = `${percent}%`;
    
    const traumaList = document.getElementById('trauma-list');
    traumaList.innerHTML = '';
    state.activeInjuries.forEach(inj => {
        const div = document.createElement('div');
        div.className = 'trauma-card';
        div.innerHTML = `<span class="part">[${getPartNameLatvian(inj.part)}]</span> ${inj.name} <span class="severity">DPS: ${inj.dps}</span>`;
        traumaList.appendChild(div);
    });
}

function getPartNameLatvian(part) {
    const names = { head: 'GALVA', torso: 'TORSS', 'arm-l': 'K. ROKA', 'arm-r': 'L. ROKA', 'leg-l': 'K. KĀJA', 'leg-r': 'L. KĀJA' };
    return names[part] || part.toUpperCase();
}

function updateBodyPartVisuals() {
    document.querySelectorAll('.body-part').forEach(part => {
        const partId = part.dataset.part;
        const isInjured = state.activeInjuries.some(i => i.part === partId);
        if (isInjured) part.classList.add('injured');
        else part.classList.remove('injured');
    });
}

function failureTreatment() {
    state.hp -= 15;
    consumeItem();
    showActionHint("KĻŪDA: PRIEKŠMETS IZLIETOTS VELTI. -15 HP");
}

function showActionHint(text) {
    const hint = document.getElementById('action-hint');
    hint.innerText = text;
    setTimeout(() => { 
        if(!state.isGameOver) hint.innerText = "GATAVS DIAGNOSTIKAI"; 
    }, 3000);
}

function renderWiki() {
    const container = document.getElementById('wiki-container');
    container.innerHTML = "";
    const allTraumas = [...TRAUMA_POOL.common, ...TRAUMA_POOL.rare, ...TRAUMA_POOL.lethal];
    allTraumas.forEach(t => {
        const entry = document.createElement('div');
        entry.className = 'wiki-entry';
        let treatment = "Pārsējs";
        if (t.name === 'Dziļš griezums') treatment = "Pārsējs vai Ķirurģiskā adata un diegi";
        if (t.name === 'Asins saindēšanās') treatment = "Antibiotikas";
        if (t.name === 'Kaula lūzums') treatment = "Protokols prasa vispirms izmantot ķirurģisko pinceti kaulu fragmentu repozīcijai, pēc tam bojātajai vietai jāuzliek medicīniskais ģipsis imobilizācijai.";
        if (t.name === 'Arteriālā asiņošana') treatment = "Kritisks stāvoklis, kam nepieciešama tūlītēja žņauga uzlikšana pagaidu asins zuduma apturēšanai. Pēc stabilizācijas jāizmanto ķirurģiskā adata bojātā asinsvada galīgai slēgšanai un pēc tam žņaugu var noņemt.";
        if (t.name === 'Iekšējā asiņošana' || t.name === 'Galvaskausa lūzums') treatment = "Sarežģīta intervence. Nepieciešams izmantot skalpeli operatīvai piekļuvei, pēc tam ķirurģisko pinceti problēmas avota novēršanai un, visbeidzot, ķirurģisko adatu griezuma aizvēršanai.";
        if (t.name === 'Sirdsdarbības apstāšanās') treatment = "Augstākā prioritāte. Procedūra ietver skalpeļa un ķirurģiskās pincetes izmantošanu. Pēc piekļuves nodrošināšanas miokardam jāizmanto defibrilators ritma atjaunošanai un tikai pēc tam brūce jāaizver ar ķirurģisko adatu.";
        
        entry.innerHTML = `
            <div class="wiki-title">${t.name.toUpperCase()}</div>
            <div class="wiki-main">
                <div class="wiki-icon"><img src="${t.icn}" alt=""></div>
                <div class="wiki-info">
                    <div class="wiki-row"><span class="wiki-label">Efekti:</span> ${t.dps} veselības vienību zudums ik pēc 5 sekundēm.</div>
                    <div class="wiki-row"><span class="wiki-label">Ārstēšana:</span> ${treatment}</div>
                    <div class="wiki-row"><span class="wiki-label">Izraisīts:</span> Fizisks bojājums, piesardzības pasākumu trūkums.</div>
                    <div class="wiki-row"><span class="wiki-label">Tags:</span> Traumatisms, ${t.dps > 20 ? 'Kritisks' : 'Standarta'}.</div>
                </div>
            </div>
            <div class="wiki-row"><span class="wiki-label">Medicīniskā definīcija:</span> ${t.definition}</div>
            <div class="wiki-row"><span class="wiki-label">SSK-10:</span> ${t.icd}</div>
        `;
        container.appendChild(entry);
    });
}

function gameOver() {
    state.isGameOver = true;
    document.getElementById('death-screen').classList.remove('hidden');
    document.getElementById('action-hint').innerText = "OBJEKTS MIRIS";

    // Передача финального времени на экран смерти
    const minutes = Math.floor(state.survivalSeconds / 60);
    const seconds = state.survivalSeconds % 60;
    const formattedTime = minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;
    document.getElementById('final-survival-time').innerText = formattedTime;
}

function resetGame() {
    state = { credits: 0, hp: 200, maxHp: 200, inventory: [], activeInjuries: [], selectedItemIdx: -1, isGameOver: false, tickTimer: 5000, survivalSeconds: 0 };
    document.getElementById('death-screen').classList.add('hidden');
    updateSurvivalTimerUI();
    updateBodyPartVisuals();
    renderInventory();
    updateUI();
}